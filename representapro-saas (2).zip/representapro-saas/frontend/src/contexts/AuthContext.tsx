import {
  ReactNode,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { api, setAccessTokenForRequests } from "../services/api";
import { AuthUser } from "../types/auth";

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  const applySession = useCallback((accessToken: string, sessionUser: AuthUser) => {
    setAccessTokenForRequests(accessToken);
    setUser(sessionUser);
  }, []);

  useEffect(() => {
    // Ao carregar o app, tenta renovar a sessão usando o cookie httpOnly do
    // refresh token (se existir) — evita pedir login de novo a cada F5.
    api
      .post("/auth/refresh")
      .then(({ data }) => applySession(data.accessToken, data.user))
      .catch(() => setAccessTokenForRequests(null))
      .finally(() => setLoading(false));
  }, [applySession]);

  async function login(email: string, password: string) {
    const { data } = await api.post("/auth/login", { email, password });
    applySession(data.accessToken, data.user);
  }

  async function logout() {
    await api.post("/auth/logout").catch(() => undefined);
    setAccessTokenForRequests(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth precisa ser usado dentro de <AuthProvider>");
  }
  return ctx;
}
