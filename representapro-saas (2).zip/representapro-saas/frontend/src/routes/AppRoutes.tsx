import { Route, Routes } from "react-router-dom";
import { Login } from "../pages/Login";
import { Dashboard } from "../pages/Dashboard";
import { ProtectedRoute } from "../components/ProtectedRoute";

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />
      {/* Demais rotas (clientes, representadas, produtos, pedidos,
          vendedores, comissões, metas, visitas, agenda, negociações,
          relatórios, configurações) entram junto com cada módulo,
          seguindo as fases combinadas — todas dentro de ProtectedRoute. */}
    </Routes>
  );
}
