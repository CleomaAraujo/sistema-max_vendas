import { useAuth } from "../contexts/AuthContext";

export function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <div style={{ padding: 32 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <h1 style={{ marginBottom: 4 }}>Dashboard</h1>
          <p style={{ color: "#888" }}>
            {user?.tenantNome} — {user?.nome} ({user?.role})
          </p>
        </div>
        <button onClick={() => logout()}>Sair</button>
      </div>

      <p style={{ color: "#888", marginTop: 24 }}>
        Indicadores comerciais (vendas, pedidos, clientes, comissões) entram
        na Fase 5 — Gestão.
      </p>
    </div>
  );
}
