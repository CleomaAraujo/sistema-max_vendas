import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";

const baseURL = import.meta.env.VITE_API_URL ?? "http://localhost:3333";

export const api = axios.create({
  baseURL,
  // necessário para o navegador enviar/receber o cookie httpOnly do refresh token
  withCredentials: true,
});

// O access token vive só em memória (nunca localStorage/sessionStorage) —
// reduz bastante a superfície de ataque de XSS. Ele é perdido a cada reload
// de página de propósito; o AuthProvider renova a sessão no boot chamando
// /auth/refresh, que usa o cookie httpOnly.
let currentAccessToken: string | null = null;

export function setAccessTokenForRequests(token: string | null) {
  currentAccessToken = token;
}

api.interceptors.request.use((config) => {
  if (currentAccessToken) {
    config.headers.set("Authorization", `Bearer ${currentAccessToken}`);
  }
  return config;
});

let refreshEmAndamento: Promise<string | null> | null = null;

async function tentarRenovarToken(): Promise<string | null> {
  if (!refreshEmAndamento) {
    refreshEmAndamento = axios
      .post(`${baseURL}/auth/refresh`, {}, { withCredentials: true })
      .then((res) => {
        const token = res.data.accessToken as string;
        currentAccessToken = token;
        return token;
      })
      .catch(() => null)
      .finally(() => {
        refreshEmAndamento = null;
      });
  }
  return refreshEmAndamento;
}

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const original = error.config as (InternalAxiosRequestConfig & { _retry?: boolean }) | undefined;
    const isRefreshCall = original?.url?.includes("/auth/refresh");

    if (error.response?.status === 401 && original && !original._retry && !isRefreshCall) {
      original._retry = true;
      const novoToken = await tentarRenovarToken();
      if (novoToken) {
        original.headers.set("Authorization", `Bearer ${novoToken}`);
        return api(original);
      }
    }

    return Promise.reject(error);
  }
);
