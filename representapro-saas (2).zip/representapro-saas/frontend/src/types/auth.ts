export type UserRole =
  | "administrador"
  | "gerente"
  | "vendedor"
  | "financeiro"
  | "visualizador";

export interface AuthUser {
  id: string;
  tenantId: string;
  tenantNome: string;
  nome: string;
  email: string;
  role: UserRole;
}
