import { ReactElement } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export function ProtectedRoute({ children }: { children: ReactElement }) {
  const { user, loading } = useAuth();

  if (loading) {
    return null; // poderia ser um spinner de carregamento
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
