import { NextFunction, Request, Response } from "express";
import { verifyAccessToken } from "../auth/jwt";
import { AppError } from "./errorHandler";

export interface AuthenticatedRequest extends Request {
  auth?: {
    userId: string;
    tenantId: string;
    role: string;
  };
}

export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return next(new AppError("Não autenticado", 401));
  }

  try {
    const payload = verifyAccessToken(header.slice("Bearer ".length));
    (req as AuthenticatedRequest).auth = {
      userId: payload.sub,
      tenantId: payload.tenantId,
      role: payload.role,
    };
    next();
  } catch {
    next(new AppError("Sessão expirada", 401));
  }
}

/** Restringe a rota a perfis específicos. Ex.: requireRole("administrador") */
export function requireRole(...allowed: string[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    const auth = (req as AuthenticatedRequest).auth;
    if (!auth || !allowed.includes(auth.role)) {
      return next(new AppError("Sem permissão para este recurso", 403));
    }
    next();
  };
}
