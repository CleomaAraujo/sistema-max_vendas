import { NextFunction, Request, RequestHandler, Response } from "express";

// O Express 4 não captura automaticamente erros de handlers async — uma
// Promise rejeitada dentro de um handler simplesmente trava a request sem
// cair no errorHandler. Esse wrapper resolve isso: qualquer throw/reject
// vira next(err), que cai no errorHandler normalmente.
export function asyncHandler<Req extends Request = Request>(
  fn: (req: Req, res: Response) => Promise<void | Response>
): RequestHandler {
  return (req, res, next: NextFunction) => {
    fn(req as Req, res).catch(next);
  };
}
