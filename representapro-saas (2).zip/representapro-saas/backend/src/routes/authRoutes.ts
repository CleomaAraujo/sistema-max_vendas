import { Router } from "express";
import * as authController from "../controllers/authController";
import { asyncHandler } from "../middlewares/asyncHandler";
import { requireAuth, AuthenticatedRequest } from "../middlewares/authMiddleware";

export const authRoutes = Router();

authRoutes.post("/login", asyncHandler(authController.login));
authRoutes.post("/refresh", asyncHandler(authController.refresh));
authRoutes.post("/logout", asyncHandler(authController.logout));
authRoutes.get("/me", requireAuth, asyncHandler<AuthenticatedRequest>(authController.me));
