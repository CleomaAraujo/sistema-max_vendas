import crypto from "node:crypto";
import { PoolClient } from "pg";
import { withServiceContext, withTenant } from "../database/pool";
import { comparePassword } from "../auth/password";
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  REFRESH_EXPIRES_IN_MS,
} from "../auth/jwt";
import { AppError } from "../middlewares/errorHandler";

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export interface SessionUser {
  id: string;
  tenantId: string;
  tenantNome: string;
  nome: string;
  email: string;
  role: string;
}

export interface AuthResult {
  accessToken: string;
  refreshToken: string;
  refreshTokenMaxAgeMs: number;
  user: SessionUser;
}

async function issueTokens(
  client: PoolClient,
  userId: string,
  tenantId: string,
  role: string
): Promise<{ accessToken: string; refreshToken: string; refreshTokenMaxAgeMs: number }> {
  const jti = crypto.randomUUID();
  const accessToken = signAccessToken({ sub: userId, tenantId, role });
  const refreshToken = signRefreshToken({ sub: userId, tenantId, jti });
  const expiresAt = new Date(Date.now() + REFRESH_EXPIRES_IN_MS);

  await client.query(
    `INSERT INTO refresh_tokens (tenant_id, user_id, jti, token_hash, expires_at)
     VALUES ($1, $2, $3, $4, $5)`,
    [tenantId, userId, jti, hashToken(refreshToken), expiresAt]
  );

  return { accessToken, refreshToken, refreshTokenMaxAgeMs: REFRESH_EXPIRES_IN_MS };
}

export async function login(email: string, password: string): Promise<AuthResult> {
  // Não sabemos o tenant ainda (a tela de login só pede e-mail/senha) —
  // essa busca por e-mail precisa do bypass controlado.
  const found = await withServiceContext(async (client) => {
    const { rows } = await client.query(
      `SELECT u.id, u.tenant_id, u.nome, u.email, u.password_hash, u.status,
              r.slug AS role, t.nome_fantasia AS tenant_nome, t.status AS tenant_status
       FROM users u
       JOIN roles r ON r.id = u.role_id
       JOIN tenants t ON t.id = u.tenant_id
       WHERE u.email = $1`,
      [email]
    );
    return rows[0];
  });

  const senhaConfere = found ? await comparePassword(password, found.password_hash) : false;

  if (!found || !senhaConfere || found.status !== "ativo" || found.tenant_status !== "ativo") {
    // Mensagem genérica de propósito — não dá dica se o problema foi o
    // e-mail não existir, senha errada ou usuário/tenant desativado.
    throw new AppError("E-mail ou senha inválidos", 401);
  }

  // A partir daqui já sabemos o tenant — uso normal, sem bypass.
  const tokens = await withTenant(found.tenant_id, (client) =>
    issueTokens(client, found.id, found.tenant_id, found.role)
  );

  return {
    ...tokens,
    user: {
      id: found.id,
      tenantId: found.tenant_id,
      tenantNome: found.tenant_nome,
      nome: found.nome,
      email: found.email,
      role: found.role,
    },
  };
}

export async function refresh(refreshToken: string): Promise<AuthResult> {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw new AppError("Sessão expirada, faça login novamente", 401);
  }

  const tokenHash = hashToken(refreshToken);

  return withTenant(payload.tenantId, async (client) => {
    const { rows } = await client.query(
      `SELECT rt.id, rt.revoked_at, rt.expires_at,
              u.id AS user_id, u.nome, u.email, u.status,
              r.slug AS role, t.nome_fantasia AS tenant_nome
       FROM refresh_tokens rt
       JOIN users u ON u.id = rt.user_id
       JOIN roles r ON r.id = u.role_id
       JOIN tenants t ON t.id = u.tenant_id
       WHERE rt.jti = $1 AND rt.token_hash = $2`,
      [payload.jti, tokenHash]
    );

    const record = rows[0];
    const valido =
      record &&
      !record.revoked_at &&
      new Date(record.expires_at) > new Date() &&
      record.status === "ativo";

    if (!valido) {
      // Se alguém reusar um refresh token já rotacionado/revogado, é sinal
      // de token roubado — aqui seria o lugar de revogar TODOS os tokens
      // do usuário por segurança, quando esse alerta for implementado.
      throw new AppError("Sessão expirada, faça login novamente", 401);
    }

    // Rotação: o token usado morre, um par novo nasce.
    await client.query(`UPDATE refresh_tokens SET revoked_at = now() WHERE id = $1`, [record.id]);

    const tokens = await issueTokens(client, record.user_id, payload.tenantId, record.role);

    return {
      ...tokens,
      user: {
        id: record.user_id,
        tenantId: payload.tenantId,
        tenantNome: record.tenant_nome,
        nome: record.nome,
        email: record.email,
        role: record.role,
      },
    };
  });
}

export async function logout(refreshToken: string): Promise<void> {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    return; // token já inválido/expirado — nada a revogar
  }

  const tokenHash = hashToken(refreshToken);

  await withTenant(payload.tenantId, (client) =>
    client.query(
      `UPDATE refresh_tokens SET revoked_at = now()
       WHERE jti = $1 AND token_hash = $2 AND revoked_at IS NULL`,
      [payload.jti, tokenHash]
    )
  );
}

export async function getUserById(tenantId: string, userId: string): Promise<SessionUser | null> {
  return withTenant(tenantId, async (client) => {
    const { rows } = await client.query(
      `SELECT u.id, u.tenant_id, u.nome, u.email, r.slug AS role, t.nome_fantasia AS tenant_nome
       FROM users u
       JOIN roles r ON r.id = u.role_id
       JOIN tenants t ON t.id = u.tenant_id
       WHERE u.id = $1`,
      [userId]
    );

    if (!rows[0]) return null;

    return {
      id: rows[0].id,
      tenantId: rows[0].tenant_id,
      tenantNome: rows[0].tenant_nome,
      nome: rows[0].nome,
      email: rows[0].email,
      role: rows[0].role,
    };
  });
}
