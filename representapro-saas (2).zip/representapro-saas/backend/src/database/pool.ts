import { Pool, PoolClient } from "pg";

// Pool único de conexões com o PostgreSQL.
// A DATABASE_URL vem do PaaS (Railway/Render/Fly.io) via variável de ambiente.
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30_000,
});

/**
 * Executa uma função dentro de uma transação que já tem o tenant_id
 * setado na sessão do Postgres (app.tenant_id), para que as policies
 * de Row Level Security filtrem automaticamente os dados daquele tenant.
 *
 * Uso típico dentro de um controller/service:
 *   const clientes = await withTenant(tenantId, (client) =>
 *     client.query("SELECT * FROM clients")
 *   );
 */
export async function withTenant<T>(
  tenantId: string,
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    // set_config com o 3º argumento true = só vale para esta transação
    await client.query("SELECT set_config('app.tenant_id', $1, true)", [tenantId]);
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Executa uma função com app.bypass_rls = 'on' na sessão, ou seja, IGNORANDO
 * o isolamento por tenant das tabelas com FORCE ROW LEVEL SECURITY.
 *
 * Uso restrito a fluxos internos e controlados pelo próprio backend:
 *   - login: procurar o usuário pelo e-mail ANTES de saber o tenant_id
 *     (a tela de login não pergunta "empresa", ver src/pages/Login.tsx)
 *   - scripts de seed/manutenção
 *   - painel administrativo da plataforma (Fase 6 — enxerga todos os tenants)
 *
 * NUNCA usar isto num caminho que aceite tenant_id vindo do próprio usuário
 * final autenticado — nesses casos use sempre withTenant().
 */
export async function withServiceContext<T>(
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT set_config('app.bypass_rls', 'on', true)");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
