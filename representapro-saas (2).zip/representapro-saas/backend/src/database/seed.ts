import "dotenv/config";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { PoolClient } from "pg";
import { pool, withServiceContext } from "./pool";

// Catálogo de módulos do sistema. Cada módulo gera duas permissões:
// "<modulo>.visualizar" e "<modulo>.gerenciar".
const MODULOS = [
  "clientes",
  "representadas",
  "produtos",
  "pedidos",
  "vendedores",
  "comissoes",
  "metas",
  "visitas",
  "agenda",
  "negociacoes",
  "relatorios",
  "financeiro",
  "configuracoes",
] as const;

// Quais módulos cada perfil gerencia (visualizar + gerenciar).
const ROLES: Record<string, { nome: string; modulosGerenciar: string[] }> = {
  administrador: { nome: "Administrador", modulosGerenciar: [...MODULOS] },
  gerente: {
    nome: "Gerente",
    modulosGerenciar: ["clientes", "pedidos", "vendedores", "metas", "relatorios"],
  },
  vendedor: {
    nome: "Vendedor",
    modulosGerenciar: ["clientes", "visitas", "pedidos", "agenda", "produtos", "negociacoes"],
  },
  financeiro: {
    nome: "Financeiro",
    modulosGerenciar: ["pedidos", "comissoes", "financeiro"],
  },
  visualizador: { nome: "Visualizador", modulosGerenciar: [] },
};

async function seedRolesEPermissions(client: PoolClient) {
  const permissionIds = new Map<string, string>();

  for (const modulo of MODULOS) {
    for (const acao of ["visualizar", "gerenciar"] as const) {
      const slug = `${modulo}.${acao}`;
      const { rows } = await client.query(
        `INSERT INTO permissions (slug, modulo, acao, descricao)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (slug) DO UPDATE SET slug = EXCLUDED.slug
         RETURNING id`,
        [slug, modulo, acao, `${acao} em ${modulo}`]
      );
      permissionIds.set(slug, rows[0].id);
    }
  }

  const roleIds = new Map<string, string>();

  for (const [slug, def] of Object.entries(ROLES)) {
    const { rows } = await client.query(
      `INSERT INTO roles (slug, nome)
       VALUES ($1, $2)
       ON CONFLICT (slug) DO UPDATE SET nome = EXCLUDED.nome
       RETURNING id`,
      [slug, def.nome]
    );
    roleIds.set(slug, rows[0].id);
  }

  for (const [slug, def] of Object.entries(ROLES)) {
    const roleId = roleIds.get(slug)!;

    for (const modulo of MODULOS) {
      const visualizarId = permissionIds.get(`${modulo}.visualizar`)!;
      await client.query(
        `INSERT INTO role_permissions (role_id, permission_id)
         VALUES ($1, $2) ON CONFLICT DO NOTHING`,
        [roleId, visualizarId]
      );
    }

    for (const modulo of def.modulosGerenciar) {
      const gerenciarId = permissionIds.get(`${modulo}.gerenciar`)!;
      await client.query(
        `INSERT INTO role_permissions (role_id, permission_id)
         VALUES ($1, $2) ON CONFLICT DO NOTHING`,
        [roleId, gerenciarId]
      );
    }
  }

  return roleIds;
}

async function seedTenantEAdmin(client: PoolClient, roleIds: Map<string, string>) {
  const { rows: tenantRows } = await client.query(
    `INSERT INTO tenants (razao_social, nome_fantasia, plano, status)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (cnpj) DO NOTHING
     RETURNING id`,
    ["LBM Representação Comercial", "LBM", "profissional", "ativo"]
  );

  let tenantId = tenantRows[0]?.id;
  if (!tenantId) {
    const { rows } = await client.query(
      `SELECT id FROM tenants WHERE razao_social = $1 LIMIT 1`,
      ["LBM Representação Comercial"]
    );
    tenantId = rows[0]?.id;
  }

  const email = "cleomar@lbm.com.br";

  // Esta busca funciona mesmo sem app.tenant_id setado porque estamos
  // dentro de withServiceContext (app.bypass_rls = 'on').
  const { rows: existing } = await client.query(
    `SELECT id FROM users WHERE email = $1`,
    [email]
  );

  if (existing.length > 0) {
    console.log(`Usuário administrador já existe (${email}) — nada a fazer.`);
    return;
  }

  const senhaProvisoria = crypto.randomBytes(6).toString("base64url");
  const passwordHash = await bcrypt.hash(senhaProvisoria, 10);

  await client.query(
    `INSERT INTO users (tenant_id, role_id, nome, email, password_hash, status)
     VALUES ($1, $2, $3, $4, $5, 'ativo')`,
    [tenantId, roleIds.get("administrador"), "Cleomar", email, passwordHash]
  );

  console.log("=====================================================");
  console.log("Tenant criado: LBM Representação Comercial");
  console.log("Usuário administrador:", email);
  console.log("Senha provisória:", senhaProvisoria);
  console.log("(troque essa senha assim que o login estiver implementado)");
  console.log("=====================================================");
}

async function main() {
  await withServiceContext(async (client) => {
    const roleIds = await seedRolesEPermissions(client);
    await seedTenantEAdmin(client, roleIds);
  });
  await pool.end();
}

main().catch((err) => {
  console.error("Erro ao rodar o seed:", err);
  process.exit(1);
});
