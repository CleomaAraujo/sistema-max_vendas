import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { errorHandler } from "./middlewares/errorHandler";
import { authRoutes } from "./routes/authRoutes";

const app = express();

app.use(helmet());
app.use(
  cors({
    // credentials:true + origin explícito (não "*") são obrigatórios para o
    // navegador aceitar mandar/receber o cookie httpOnly do refresh token.
    origin: process.env.CORS_ORIGIN ?? "http://localhost:5173",
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());

// Health check — útil para o PaaS (Railway/Render/Fly.io) saber que o serviço está de pé
app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "representapro-backend" });
});

app.use("/auth", authRoutes);

// Demais rotas de negócio entram aqui conforme cada módulo for construído,
// sempre atrás de requireAuth (e requireRole quando fizer sentido):
// app.use("/clients", requireAuth, clientRoutes);
// ...

app.use(errorHandler);

const PORT = process.env.PORT ? Number(process.env.PORT) : 3333;

app.listen(PORT, () => {
  console.log(`RepresentaPro backend rodando na porta ${PORT}`);
});
