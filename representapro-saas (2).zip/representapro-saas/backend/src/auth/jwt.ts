import jwt from "jsonwebtoken";

export interface AccessTokenPayload {
  sub: string; // user id
  tenantId: string;
  role: string; // slug do perfil (administrador, gerente, vendedor, financeiro, visualizador)
}

export interface RefreshTokenPayload {
  sub: string;
  tenantId: string;
  jti: string; // id único deste refresh token, usado para revogação no banco
}

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET ?? "";
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET ?? "";
const ACCESS_EXPIRES_IN = process.env.JWT_ACCESS_EXPIRES_IN ?? "15m";
const REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN ?? "30d";

if (!ACCESS_SECRET || !REFRESH_SECRET) {
  // Falha alto e cedo: rodar em produção sem esses segredos é um risco de
  // segurança grave demais para deixar passar batido.
  throw new Error(
    "JWT_ACCESS_SECRET e JWT_REFRESH_SECRET precisam estar definidos (veja backend/.env.example)"
  );
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, ACCESS_SECRET, { expiresIn: ACCESS_EXPIRES_IN });
}

export function signRefreshToken(payload: RefreshTokenPayload): string {
  return jwt.sign(payload, REFRESH_SECRET, { expiresIn: REFRESH_EXPIRES_IN });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, ACCESS_SECRET) as AccessTokenPayload;
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  return jwt.verify(token, REFRESH_SECRET) as RefreshTokenPayload;
}

/** Converte "15m" / "30d" em milissegundos, para usar no maxAge do cookie. */
export function expiresInToMs(expiresIn: string): number {
  const match = /^(\d+)([smhd])$/.exec(expiresIn.trim());
  if (!match) return 15 * 60 * 1000;

  const value = Number(match[1]);
  const unitMs: Record<string, number> = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
  return value * unitMs[match[2]];
}

export const REFRESH_EXPIRES_IN_MS = expiresInToMs(REFRESH_EXPIRES_IN);
