// Converte strings como "15m", "30d", "12h", "45s" em milissegundos.
// Usado tanto para o expiresIn do JWT quanto para o maxAge do cookie
// e para calcular expires_at no banco.
const UNIDADES: Record<string, number> = {
  s: 1000,
  m: 60 * 1000,
  h: 60 * 60 * 1000,
  d: 24 * 60 * 60 * 1000,
};

export function parseDuration(value: string): number {
  const match = /^(\d+)([smhd])$/.exec(value.trim());
  if (!match) {
    throw new Error(`Formato de duração inválido: "${value}" (use algo como 15m, 12h, 30d)`);
  }
  const [, quantidade, unidade] = match;
  return Number(quantidade) * UNIDADES[unidade];
}
