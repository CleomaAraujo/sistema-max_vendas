import { Request, Response } from "express";
import { z } from "zod";
import * as authService from "../services/authService";
import { AuthenticatedRequest } from "../middlewares/authMiddleware";
import { AppError } from "../middlewares/errorHandler";

// Cookie do refresh token — httpOnly (JS do navegador não consegue ler),
// enviado só para /auth (path restrito), o que impede que ele vaze junto
// com requests para outras rotas que não precisam dele.
export const REFRESH_COOKIE = "representapro_refresh_token";

function setRefreshCookie(res: Response, token: string, maxAgeMs: number) {
  res.cookie(REFRESH_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: maxAgeMs,
    path: "/auth",
  });
}

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function login(req: Request, res: Response) {
  const { email, password } = loginSchema.parse(req.body);
  const result = await authService.login(email, password);

  setRefreshCookie(res, result.refreshToken, result.refreshTokenMaxAgeMs);
  res.json({ accessToken: result.accessToken, user: result.user });
}

export async function refresh(req: Request, res: Response) {
  const token = req.cookies?.[REFRESH_COOKIE];
  if (!token) {
    throw new AppError("Sessão não encontrada", 401);
  }

  const result = await authService.refresh(token);
  setRefreshCookie(res, result.refreshToken, result.refreshTokenMaxAgeMs);
  res.json({ accessToken: result.accessToken, user: result.user });
}

export async function logout(req: Request, res: Response) {
  const token = req.cookies?.[REFRESH_COOKIE];
  if (token) {
    await authService.logout(token);
  }
  res.clearCookie(REFRESH_COOKIE, { path: "/auth" });
  res.status(204).send();
}

export async function me(req: AuthenticatedRequest, res: Response) {
  const user = await authService.getUserById(req.auth!.tenantId, req.auth!.userId);
  if (!user) {
    throw new AppError("Usuário não encontrado", 404);
  }
  res.json({ user });
}
