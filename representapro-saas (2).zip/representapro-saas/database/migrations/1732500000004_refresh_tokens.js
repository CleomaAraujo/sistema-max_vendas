const { enableTenantRls } = require("./_lib/rls");

exports.shorthands = undefined;

exports.up = (pgm) => {
  pgm.createTable("refresh_tokens", {
    id: { type: "uuid", primaryKey: true, default: pgm.func("gen_random_uuid()") },
    tenant_id: { type: "uuid", notNull: true, references: "tenants", onDelete: "CASCADE" },
    user_id: { type: "uuid", notNull: true, references: "users", onDelete: "CASCADE" },
    jti: { type: "text", notNull: true, unique: true }, // id único do token (vem no payload do JWT)
    token_hash: { type: "text", notNull: true }, // sha256 do JWT — nunca guardamos o token em texto puro
    expires_at: { type: "timestamptz", notNull: true },
    revoked_at: { type: "timestamptz" }, // preenchido no logout ou na rotação (refresh)
    created_at: { type: "timestamptz", notNull: true, default: pgm.func("now()") },
  });

  pgm.createIndex("refresh_tokens", "user_id");
  pgm.createIndex("refresh_tokens", "tenant_id");

  enableTenantRls(pgm, "refresh_tokens");
};

exports.down = (pgm) => {
  pgm.dropTable("refresh_tokens");
};
