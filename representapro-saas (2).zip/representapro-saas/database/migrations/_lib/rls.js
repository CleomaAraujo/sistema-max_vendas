// Helper reutilizável: aplica o padrão de isolamento por tenant (Row Level
// Security) numa tabela que tenha a coluna tenant_id. Será usado por esta
// migration (users) e por todas as tabelas comerciais que chegarem na
// Fase 2 (clientes, produtos, pedidos, etc.).
//
// IMPORTANTE — por que FORCE ROW LEVEL SECURITY:
// a maioria dos PaaS gerenciados (Railway/Render/Fly.io) te dá um único
// usuário de banco, que é o DONO das tabelas. Por padrão, o Postgres NÃO
// aplica RLS ao dono da tabela — ou seja, sem o FORCE, a própria aplicação
// ignoraria essas policies sem perceber. FORCE fecha essa brecha.
//
// Como a policy libera acesso:
//   1) tenant_id bate com o app.tenant_id setado na sessão (fluxo normal,
//      ver withTenant() em src/database/pool.ts), OU
//   2) a sessão setou explicitamente app.bypass_rls = 'on' (só usado em
//      fluxos internos e controlados — ver withServiceContext()).
// Se nenhuma das duas condições for verdadeira, a linha simplesmente não
// aparece (fail-closed): esquecer de setar o tenant nunca vaza dado de
// outro tenant, só faz a query voltar vazia.
function enableTenantRls(pgm, table) {
  pgm.sql(`ALTER TABLE ${table} ENABLE ROW LEVEL SECURITY`);
  pgm.sql(`ALTER TABLE ${table} FORCE ROW LEVEL SECURITY`);

  const condicao = `(
    tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid
    OR current_setting('app.bypass_rls', true) = 'on'
  )`;

  pgm.sql(`
    CREATE POLICY ${table}_tenant_isolation ON ${table}
    USING ${condicao}
    WITH CHECK ${condicao}
  `);
}

function disableTenantRls(pgm, table) {
  pgm.sql(`DROP POLICY IF EXISTS ${table}_tenant_isolation ON ${table}`);
  pgm.sql(`ALTER TABLE ${table} NO FORCE ROW LEVEL SECURITY`);
  pgm.sql(`ALTER TABLE ${table} DISABLE ROW LEVEL SECURITY`);
}

module.exports = { enableTenantRls, disableTenantRls };
