exports.shorthands = undefined;

exports.up = (pgm) => {
  pgm.createTable("users", {
    id: { type: "uuid", primaryKey: true, default: pgm.func("gen_random_uuid()") },
    tenant_id: { type: "uuid", notNull: true, references: "tenants", onDelete: "CASCADE" },
    role_id: { type: "uuid", notNull: true, references: "roles" },
    nome: { type: "text", notNull: true },
    // e-mail é único em toda a plataforma (não só no tenant), porque o
    // login não pede "empresa" — o tenant é descoberto a partir do e-mail.
    email: { type: "text", notNull: true, unique: true },
    password_hash: { type: "text", notNull: true },
    status: { type: "text", notNull: true, default: "ativo" }, // ativo | inativo
    created_at: { type: "timestamptz", notNull: true, default: pgm.func("now()") },
    updated_at: { type: "timestamptz", notNull: true, default: pgm.func("now()") },
  });

  pgm.createIndex("users", "tenant_id");
};

exports.down = (pgm) => {
  pgm.dropTable("users");
};
