exports.shorthands = undefined;

// roles/permissions são globais à plataforma (não têm tenant_id):
// os 5 perfis e o catálogo de permissões são os mesmos para todo mundo,
// o que muda por tenant é apenas QUAIS usuários têm qual role.

exports.up = (pgm) => {
  pgm.createTable("roles", {
    id: { type: "uuid", primaryKey: true, default: pgm.func("gen_random_uuid()") },
    slug: { type: "text", notNull: true, unique: true }, // administrador | gerente | vendedor | financeiro | visualizador
    nome: { type: "text", notNull: true },
    created_at: { type: "timestamptz", notNull: true, default: pgm.func("now()") },
  });

  pgm.createTable("permissions", {
    id: { type: "uuid", primaryKey: true, default: pgm.func("gen_random_uuid()") },
    slug: { type: "text", notNull: true, unique: true }, // ex: clientes.visualizar / clientes.gerenciar
    modulo: { type: "text", notNull: true }, // ex: clientes, pedidos, comissoes...
    acao: { type: "text", notNull: true }, // visualizar | gerenciar
    descricao: { type: "text" },
  });

  pgm.createTable("role_permissions", {
    role_id: { type: "uuid", notNull: true, references: "roles", onDelete: "CASCADE" },
    permission_id: { type: "uuid", notNull: true, references: "permissions", onDelete: "CASCADE" },
  });

  pgm.addConstraint("role_permissions", "role_permissions_pkey", {
    primaryKey: ["role_id", "permission_id"],
  });
};

exports.down = (pgm) => {
  pgm.dropTable("role_permissions");
  pgm.dropTable("permissions");
  pgm.dropTable("roles");
};
