const { enableTenantRls, disableTenantRls } = require("./_lib/rls");

exports.shorthands = undefined;

exports.up = (pgm) => {
  enableTenantRls(pgm, "users");
};

exports.down = (pgm) => {
  disableTenantRls(pgm, "users");
};
