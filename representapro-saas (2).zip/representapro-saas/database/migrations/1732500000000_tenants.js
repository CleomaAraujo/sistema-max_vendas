exports.shorthands = undefined;

exports.up = (pgm) => {
  // gen_random_uuid() — usado como default de todas as chaves primárias
  pgm.createExtension("pgcrypto", { ifNotExists: true });

  pgm.createTable("tenants", {
    id: {
      type: "uuid",
      primaryKey: true,
      default: pgm.func("gen_random_uuid()"),
    },
    razao_social: { type: "text", notNull: true },
    nome_fantasia: { type: "text" },
    cnpj: { type: "text", unique: true },
    plano: { type: "text", notNull: true, default: "essencial" }, // essencial | profissional | enterprise
    status: { type: "text", notNull: true, default: "ativo" }, // ativo | suspenso | cancelado
    created_at: { type: "timestamptz", notNull: true, default: pgm.func("now()") },
    updated_at: { type: "timestamptz", notNull: true, default: pgm.func("now()") },
  });
};

exports.down = (pgm) => {
  pgm.dropTable("tenants");
};
