# database/

- `migrations/` — migrations do PostgreSQL (tenants, users, roles, permissions,
  e depois cada módulo comercial). Entram na Fase 1 - Passo 2.
- `seeds/` — dados iniciais (roles padrão, plano Essencial/Profissional/Enterprise,
  usuário administrador de exemplo).
- `migrations/_lib/rls.js` — helper `enableTenantRls(pgm, tabela)` que aplica o
  padrão de Row Level Security por tenant. Toda tabela comercial nova (Fase 2 em
  diante: clientes, produtos, pedidos...) deve chamar esse helper na sua própria
  migration, logo depois de criar a coluna `tenant_id`.
